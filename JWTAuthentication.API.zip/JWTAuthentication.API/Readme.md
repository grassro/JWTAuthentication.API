Instru��es sobre utiliza��o e funcionamento da API

1. Foi criado uma classe Migration em Authentication.Data para criar a base de dados. Seguir os passos:
	- Abrir o Package Manager Console 
	- Executar o comando Update-Database para inserir o arquivo Initial
	
2. Setar a API Authentication como projeto Startup e rodar o projeto.
   Obs: Como � apenas um servi�o, n�o abrir� um navegador. Essa configura��o foi feita em launchSettings.json 

3. Ao startar o projeto, o banco ser� populado pelo m�todo Seed em Authentication -> Program.cs
   Obs: O banco utilizado foi o SQLEXPRESS com Windows Authentication, observar em appsettings.json

4. Comentar a chamada SeedData.Initialize(context) para que n�o haja duplicidade de registros no banco de dados.

5. Verificar se a porta do IIS � a 56435