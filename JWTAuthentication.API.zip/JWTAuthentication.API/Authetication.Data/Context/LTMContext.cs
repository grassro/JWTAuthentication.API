﻿using Authetication.Data.Model;
using Microsoft.EntityFrameworkCore;

namespace Authentication.Context
{
    public class LTMContext : DbContext
    {
        public LTMContext(DbContextOptions<LTMContext> options) : base(options) { }

        public LTMContext() { }

        //Adiciona os modelos das classes no contexto
        public DbSet<Usuario> Usuario { get; set; }
        public DbSet<Produto> Produto { get; set; }

    }
}
