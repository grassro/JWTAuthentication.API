﻿using Authentication.Context;
using Authetication.Data.Model;

namespace Authetication.Data
{
    public static class SeedData
    {

        public static void Initialize(LTMContext context)
        {

            SeedDB(context);
        }


        public static void SeedDB(LTMContext context)
        {

            context.Usuario.AddRange(
                new Usuario
                {
                    UserID = "User1",
                    Password = "1234",
                },
              new Usuario
              {
                  UserID = "User2",
                  Password = "1234",
              }
             );

            context.Produto.AddRange(
                new Produto
                {
                    Descricao = "Bolacha",
                    Preco = 1.00
                },
                new Produto
                {
                    Descricao = "Sabão",
                    Preco = 3.00
                },
                new Produto
                {
                    Descricao = "Pão",
                    Preco = 5.00
                }
                );

            context.SaveChanges();
        }
    }
}
