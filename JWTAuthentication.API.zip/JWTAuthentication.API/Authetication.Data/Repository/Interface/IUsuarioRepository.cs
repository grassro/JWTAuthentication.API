﻿using Authetication.Data.Model;
using System.Threading.Tasks;

namespace Authetication.Data.Repository
{
    public interface IUsuarioRepository
    {
        Task<Usuario> Find(string userID, string password);
    }
}
