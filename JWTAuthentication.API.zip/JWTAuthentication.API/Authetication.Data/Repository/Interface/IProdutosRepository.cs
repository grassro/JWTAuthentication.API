﻿using Authetication.Data.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Authetication.Data.Repository
{
    public interface IProdutosRepository
    {
        List<Produto> GetAll();
    }
}
