﻿using Authentication.Context;
using Authetication.Data.Model;
using System.Collections.Generic;
using System.Linq;

namespace Authetication.Data.Repository
{
    public class ProdutosRepository : IProdutosRepository
    {
        private readonly LTMContext _context;

        public ProdutosRepository(LTMContext context)
        {
            _context = context;
        }

        public List<Produto> GetAll()
        {
            return _context.Produto.ToList();
        }

    }
}
