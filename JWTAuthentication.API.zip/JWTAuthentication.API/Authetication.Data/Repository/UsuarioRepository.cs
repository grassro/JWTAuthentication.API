﻿using Authentication.Context;
using Authetication.Data.Model;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace Authetication.Data.Repository
{
    public class UsuarioRepository : IUsuarioRepository
    {

        private readonly LTMContext _context;

        public UsuarioRepository(LTMContext context)
        {
            _context = context;
        }

        public async Task<Usuario> Find(string userID, string password)
        {

            var result = await _context.Usuario
                .Where(e => e.Password.Equals(password) &&
                            e.UserID.Equals(userID))
                .SingleOrDefaultAsync();


            return result;
        }
    }
}
