﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Authetication.Data.Model
{
    public class Produto
    {
        [Key]
        public string Descricao { get; set; }
        public double Preco { get; set; }
    }
}
