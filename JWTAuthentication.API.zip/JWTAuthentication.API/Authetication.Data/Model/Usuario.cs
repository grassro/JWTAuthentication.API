﻿using System.ComponentModel.DataAnnotations;

namespace Authetication.Data.Model
{
    public class Usuario
    {
        [Key]
        public string UserID { get; set; }
        public string Password { get; set; }
    }
}
