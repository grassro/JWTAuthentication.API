﻿using Authentication.Context;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Authetication.Context
{
    public class LTMContextFactory : IDesignTimeDbContextFactory<LTMContext>
    {
        /// <summary>
        /// Classe onde estanciará o contexto existente, utilizada para fazer o Code First
        /// </summary>
        /// <param name="args"></param>
        /// <returns>Retona o contexto</returns>
        public LTMContext CreateDbContext(string[] args)
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json")
            .Build();

            var builder = new DbContextOptionsBuilder<LTMContext>();

            var connectionString = configuration.GetConnectionString("LTMConnection");

            builder.UseSqlServer(connectionString);

            return new LTMContext(builder.Options);
        }

    }
}
