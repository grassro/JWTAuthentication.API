﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Authetication.Data.Repository;
using Authetication.Data.Model;

namespace Authentication.Controllers
{
    [Route("api/Produto")]
    public class ProdutoController : Controller
    {

        private readonly IProdutosRepository repo;

        public ProdutoController(IProdutosRepository _repo)
        {
            repo = _repo;
        }

        /// <summary>
        /// Lista os Produtos da base de Dados
        /// </summary>
        /// <returns></returns>
        [Authorize("Bearer")]
        [HttpGet("Listar")]
        public IEnumerable<Produto> Get()
        {

            var produtos = repo.GetAll();

            return produtos;
        }
    }
}
